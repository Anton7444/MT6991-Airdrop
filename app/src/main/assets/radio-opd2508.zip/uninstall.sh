#!/system/bin/sh
rm -rf /data/adb/owly
rm -rf /sdcard/Download/Owly
echo "owly removed"
